# CreaTuLanding1+German

Este es el proyecto base de e-commerce hecho en React usando Vite.

## Componentes creados:

- `NavBar`: Barra de navegación con logo, enlaces y carrito.
- `CartWidget`: Icono de carrito con cantidad.
- `ItemListContainer`: Muestra mensaje de bienvenida con props.

## Tecnologías

- React
- Vite
- Bootstrap (opcional)

## Cómo correr el proyecto

```bash
npm install
npm run dev
